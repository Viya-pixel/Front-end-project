document.getElementById("bookingForm").addEventListener("submit", function(event) {
    event.preventDefault();
    alert("Your bike has been successfully booked with BikeWaala!");
});
